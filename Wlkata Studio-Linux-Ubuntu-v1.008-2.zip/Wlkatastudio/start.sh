#!/bin/bash
echo start...
YOUR_GROUP='dialout'
USERNAME=`whoami`

echo `groups` |grep $YOUR_GROUP
if [ $? -gt 0 ]
then
  echo "您当前不在$YOUR_GROUP组中，没有串口控制权限，正在添加权限..."
  echo "You are not currently in the $YOUR_GROUP group, do not have serial port control permissions, and are adding permissions..."
  sudo -i usermod -aG $YOUR_GROUP $USERNAME
  echo "权限添加完成,请重启电脑后使用"
  echo "The permission is added, please restart the computer and use"
  exit
fi


export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$PWD
$PWD/Wlkata\ studio

echo exit...
