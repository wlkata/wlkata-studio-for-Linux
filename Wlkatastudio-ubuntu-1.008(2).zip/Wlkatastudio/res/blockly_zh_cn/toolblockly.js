 window.onload = function() {
     var qvc = new QWebChannel(qt.webChannelTransport, function(channel) {
         window.content = channel.objects.content;
         //receive from qt
         content.sendJsText.connect(function(text) {
                 alert(text);
             })
             //send to QT
         sendcpp = function(text) {
             content.receiveJsText(text);
         }
         content.clearContent.connect(function() {
             Code.discard();
             Code.renderContent();
         })
         content.getBlocklyCount.connect(function() {
             content.recvBlocklyCount(Code.workspace.getAllBlocks(false).length);
         })
         content.getPythonCode.connect(function() {
             content.recvForRunCode(Blockly.Python.workspaceToCode(Code.workspace));
         })
         content.saveBlockly.connect(function() {
             var xml = Blockly.Xml.workspaceToDom(Code.workspace);
             var code = Blockly.Xml.domToText(xml);
             content.recvSaveBlockly(code);
         })
         content.LoadBlocklyXml.connect(function(text) {
             var xmlDom = null;
             try {
                 xmlDom = Blockly.Xml.textToDom(text);
             } catch (e) {
                 content.receiveJsError("Bad Blockly File!");
                 return;
             }
             if (xmlDom) {
                 Code.workspace.clear();
                 Blockly.Xml.domToWorkspace(xmlDom, Code.workspace);
             }
         })
     })

 }

 Blockly.Blocks['Reset'] = {
     init: function() {
         this.appendDummyInput().appendField("复位");
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['Reset'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     return "PythonWrap.GCode('$H')\n";
 };

 Blockly.Blocks['SuctionCup'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("吸盘")
             .appendField(new Blockly.FieldDropdown([
                 ["开", "On"],
                 ["关", "Off"]
             ]), "SuctionCup");
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['SuctionCup'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var SuctionCup = block.getFieldValue('SuctionCup');
     if (SuctionCup == "On")
         return "PythonWrap.GCode('M3S1000M4E65')\n";
     else if (SuctionCup == "Off")
         return "PythonWrap.GCode('M3S0M4E40')\n";
 };

 Blockly.Blocks['GCode'] = {
     init: function() {
         this.appendValueInput('VALUE')
             .setCheck('String')
             .appendField('GCode')
             .appendField(new Blockly.FieldTextInput("默认"), "Desc");
         this.setInputsInline(true);
         this.setColour(260);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['GCode'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var cmd = Blockly.Python.valueToCode(block, 'VALUE', Blockly.Python.ORDER_ATOMIC) || '\'\'';
     return 'PythonWrap.GCode(' + cmd + ')\n';
 };

 Blockly.Blocks['Log'] = {
     init: function() {
         this.appendValueInput('VALUE')
             .setCheck('String')
             .appendField('日志');
         this.setInputsInline(true);
         this.setColour(260);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setTooltip('将调试字符串附加到脚本窗口');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['Log'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var loginfo = Blockly.Python.valueToCode(block, 'VALUE', Blockly.Python.ORDER_ATOMIC) || '\'\'';
     return 'PythonWrap.Log(' + loginfo + ')\n';
 };

 Blockly.Blocks['DOF6'] = {
     init: function() {
         this.appendDummyInput()
             .appendField('DOF6:');
         this.appendValueInput('x')
             .setCheck('Number')
             .appendField('x');
         this.appendValueInput('y')
             .setCheck('Number')
             .appendField('y');
         this.appendValueInput('z')
             .setCheck('Number')
             .appendField('z');
         this.appendValueInput('rx')
             .setCheck('Number')
             .appendField('rx');
         this.appendValueInput('ry')
             .setCheck('Number')
             .appendField('ry');
         this.appendValueInput('rz')
             .setCheck('Number')
             .appendField('rz');
         this.setInputsInline(true);
         this.setColour(260);
         this.setOutput(true, null);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['DOF6'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var x = Blockly.Python.valueToCode(block, 'x', Blockly.Python.ORDER_NONE);
     var y = Blockly.Python.valueToCode(block, 'y', Blockly.Python.ORDER_NONE);
     var z = Blockly.Python.valueToCode(block, 'z', Blockly.Python.ORDER_NONE);
     var rx = Blockly.Python.valueToCode(block, 'rx', Blockly.Python.ORDER_NONE);
     var ry = Blockly.Python.valueToCode(block, 'ry', Blockly.Python.ORDER_NONE);
     var rz = Blockly.Python.valueToCode(block, 'rz', Blockly.Python.ORDER_NONE);
     var code = 'PythonWrap.DOF6(' + x + ',' + y + ',' + z + ',' + rx + ',' + ry + ',' + rz + ')\n';
     return [code, Blockly.Python.ORDER_NONE];
 };


 //2019.8.1
 Blockly.Blocks['Init'] = {
     init: function() {
         this.appendDummyInput().appendField("回归零位");
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');

     }
 };
 Blockly.Python['Init'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     return "PythonWrap.GCode('M21 G90 G01 X0 Y0 Z0 A0 B0 C0 F2000')\n";
 };



 Blockly.Blocks["Pause"] = {
     init: function() {
         this.appendDummyInput().appendField("延迟");

         this.appendValueInput('t')
             .setCheck('Number');

         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 }
 Blockly.Python['Pause'] = function(block) {
     Blockly.Python.definitions_.import_time = "import time";

     var t = Blockly.Python.valueToCode(block, 't', Blockly.Python.ORDER_NONE);

     return "time.sleep(" + t + ")\n";
     //return "PythonWrap.GCode('Hello pause')\n";
 };


 Blockly.Blocks['MoveTo'] = {
     init: function() {
         this.appendDummyInput()
             .appendField('移动到');
         this.appendDummyInput()
             .appendField("坐标:");
         this.appendValueInput('x')
             .setCheck('Number')
             .appendField('X');
         this.appendValueInput('y')
             .setCheck('Number')
             .appendField('Y');
         this.appendValueInput('z')
             .setCheck('Number')
             .appendField('Z');
         this.appendDummyInput()
             .appendField("方向:");
         this.appendValueInput('rx')
             .setCheck('Number')
             .appendField('A');
         this.appendValueInput('ry')
             .setCheck('Number')
             .appendField('B');
         this.appendValueInput('rz')
             .setCheck('Number')
             .appendField('C');
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField('速度');
         this.setInputsInline(true);

         this.setColour(260);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setTooltip('');
         this.setHelpUrl('');

     }
 };
 Blockly.Python['MoveTo'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var x = Blockly.Python.valueToCode(block, 'x', Blockly.Python.ORDER_NONE);
     var y = Blockly.Python.valueToCode(block, 'y', Blockly.Python.ORDER_NONE);
     var z = Blockly.Python.valueToCode(block, 'z', Blockly.Python.ORDER_NONE);
     var rx = Blockly.Python.valueToCode(block, 'rx', Blockly.Python.ORDER_NONE);
     var ry = Blockly.Python.valueToCode(block, 'ry', Blockly.Python.ORDER_NONE);
     var rz = Blockly.Python.valueToCode(block, 'rz', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
     var tempValue = 'X' + x + ' Y' + y + ' Z' + z + ' A' + rx + ' B' + ry + ' C' + rz + ' F' + f;
     var codeString = "PythonWrap.GCode('M20 G90 G01 " + tempValue + "')\n";
     return codeString;
 }; //ok

 Blockly.Blocks['Speed'] = {
     init: function() {
         this.appendDummyInput()
             .appendField('速度:');
         this.appendValueInput('speed')
             .setCheck('Number');
         this.setInputsInline(true);
         this.setColour(260);
         //this.setOutput(true, null);
         this.setTooltip('return dof6 inverse result array');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['Speed'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var speed = Blockly.Python.valueToCode(block, 'speed', Blockly.Python.ORDER_NONE);
     //var code = 'PythonWrap.DOF6(' + x + ',' + y + ',' + z + ',' + rx + ',' + ry + ',' + rz + ')\n';
     // return [code, Blockly.Python.ORDER_NONE];
 };


 Blockly.Blocks['Move'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("向")
             .appendField(new Blockly.FieldDropdown([
                 ["前", "forward"],
                 ["后", "backward"],
                 ["上", "up"],
                 ["下", "down"],
                 ["右", "right"],
                 ["左", "left"]
             ]), "orientation")
			 .appendField("移动");
         this.appendValueInput('d')
             .setCheck('Number');
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField('速度');
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['Move'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var orientation = block.getFieldValue('orientation');
     var d = Blockly.Python.valueToCode(block, 'd', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
     var codeStringHeard = "PythonWrap.GCode('M20 G90 G01 "
     var codeStringTail = "')\n";
     var tempValue;
     switch (orientation) {
         case "forward":
             tempValue = "X" + d + " F" + f;
             break;
         case "backward":
             tempValue = "Y" + d + " F" + f;
             break;
         case "up":
             tempValue = "Z" + d + " F" + f;
             break;
         case "down":
             tempValue = "A" + d + " F" + f;
             break;
         case "right":
             tempValue = "B" + d + " F" + f;
             break;
         case "left":
             tempValue = "C" + d + " F" + f;
             break;
     }
     if (tempValue) {
         var codeString = codeStringHeard + tempValue + codeStringTail;
         return codeString;
     }

 }; //ok

 Blockly.Blocks['Gripper'] = {
     init: function() {
         this.appendDummyInput()
             .appendField("夹具")
             .appendField(new Blockly.FieldDropdown([
                 ["开", "On"],
                 ["关", "Off"],
             ]), "gripper");

         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['Gripper'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var gripper = block.getFieldValue('gripper');
     if (gripper == "On")
         return "PythonWrap.GCode('M3S1000M4E65')\n";
     else if (gripper == "Off")
         return "PythonWrap.GCode('M3S0M4E40')\n";

 }; //ok




 Blockly.Blocks['SliderMoveTo'] = {
     init: function() {

         this.appendDummyInput()
             .appendField("滑轨移动到:");
         this.appendValueInput('d')
             .setCheck('Number');
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField('速度');
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };
 Blockly.Python['SliderMoveTo'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var d = Blockly.Python.valueToCode(block, 'd', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);

     return "PythonWrap.GCode('M21 G90 G01 D" + d + " F" + f + "')\n";
 }; //ok


 Blockly.Blocks['TurnTo'] = {
     init: function() {
         this.appendDummyInput()
             .appendField('旋转到:');

         this.appendValueInput('x')
             .setCheck('Number')
             .appendField('关节1');

         this.appendValueInput('y')
             .setCheck('Number')
             .appendField('关节2');

         this.appendValueInput('z')
             .setCheck('Number')
             .appendField('关节3');

         this.appendValueInput('rx')
             .setCheck('Number')
             .appendField('关节4');

         this.appendValueInput('ry')
             .setCheck('Number')
             .appendField('关节5');

         this.appendValueInput('rz')
             .setCheck('Number')
             .appendField('关节6');
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField("速度");
         this.setInputsInline(true);
         this.setColour(260);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setTooltip('');
         this.setHelpUrl('');

     }
 };
 Blockly.Python['TurnTo'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var x = Blockly.Python.valueToCode(block, 'x', Blockly.Python.ORDER_NONE);
     var y = Blockly.Python.valueToCode(block, 'y', Blockly.Python.ORDER_NONE);
     var z = Blockly.Python.valueToCode(block, 'z', Blockly.Python.ORDER_NONE);
     var rx = Blockly.Python.valueToCode(block, 'rx', Blockly.Python.ORDER_NONE);
     var ry = Blockly.Python.valueToCode(block, 'ry', Blockly.Python.ORDER_NONE);
     var rz = Blockly.Python.valueToCode(block, 'rz', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
     var tempValue = 'X' + x + ' Y' + y + ' Z' + z + ' A' + rx + ' B' + ry + ' C' + rz + ' F' + f;
     var codeString = "PythonWrap.GCode('M21 G90 G01 " + tempValue + "')\n";
     return codeString;

 }; //ok


 Blockly.Blocks['Turn'] = {
     init: function() {
         this.appendDummyInput()
             .appendField(new Blockly.FieldDropdown([
                 ["关节1", "base"],
                 ["关节2", "shoulder"],
                 ["关节3", "elbow"],
                 ["关节4", "roll"],
                 ["关节5", "pitch"],
                 ["关节6", "yaw"]
             ]), "turn")
			 .appendField("延");
         this.appendDummyInput()
             .appendField(new Blockly.FieldDropdown([
                 ["顺时针", "cw"],
                 ["逆时针", "ccw"],
             ]), "rotation");
         this.appendValueInput('d')
             .setCheck('Number')
             .appendField("旋转");
         this.appendValueInput('f')
             .setCheck('Number')
             .appendField("速度");
         this.setInputsInline(true);
         this.setPreviousStatement(true, null);
         this.setNextStatement(true, null);
         this.setColour(260);
         this.setTooltip('');
         this.setHelpUrl('');
     }
 };


 Blockly.Python['Turn'] = function(block) {
     Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
     var orientation = block.getFieldValue('turn');
     var d = Blockly.Python.valueToCode(block, 'd', Blockly.Python.ORDER_NONE);
     var f = Blockly.Python.valueToCode(block, 'f', Blockly.Python.ORDER_NONE);
     var rotation = block.getFieldValue('rotation');

     var codeStringHeard = "PythonWrap.GCode('M21 G91 G01 "
     var codeStringTail = "')\n";
     var tempValue;
     if (rotation = 'ccw')
         d = -d;
     switch (orientation) {
         case "base":
             tempValue = "X" + d + " F" + f;
             break;
         case "shoulder":
             tempValue = "Y" + d + " F" + f;
             break;
         case "elbow":
             tempValue = "Z" + d + " F" + f;
             break;
         case "roll":
             tempValue = "A" + d + " F" + f;
             break;
         case "pitch":
             tempValue = "B" + d + " F" + f;
             break;
         case "yaw":
             tempValue = "C" + d + " F" + f;
             break;
     }
     if (tempValue) {
         var codeString = codeStringHeard + tempValue + codeStringTail;
         return codeString;
     }
 }; //ok

 //  Blockly.Blocks['Test'] = {
 //      init: function() {
 //          this.appendDummyInput().appendField("Test");
 //          this.setPreviousStatement(true, null);
 //          this.setNextStatement(true, null);
 //          this.setColour(170);
 //          this.setTooltip('');
 //          this.setHelpUrl('');
 //      }
 //  };
 //  Blockly.Python['Test'] = function(block) {
 //      Blockly.Python.definitions_.import_PythonWrap = "import PythonWrap";
 //      return "PythonWrap.GCode('$H')\n";
 //  };